import os
import time
import grpc
import numpy as np
import zlib
import threading
from . import hivemind_pb2
from . import hivemind_pb2_grpc

class HiveMind:
    """
    🐝 HIVEMIND CORE SDK - Versión 1.1.0 (Universal Engine)
    
    Este SDK permite delegar el procesamiento de IA a un enjambre de Androids. 
    Es agnóstico al modelo: funciona con imágenes (YOLO), texto (Llama) o audio (Whisper).
    """

    def __init__(self, server_address=None, port=None, isRealTime=False):
        """
        Summary:
            Inicializa la conexión gRPC y sincroniza el modelo activo del Back.
            
            - isRealTime=True: Para flujos constantes como VIDEO (YOLO). Mantiene un hilo
              de fondo analizando el 'último frame' disponible.
            - isRealTime=False: Para tareas discretas como CHAT o TRADUCCIÓN.
            
            Ejemplo: sdk = HiveMind(isRealTime=True)
        """
        if port is None:
            port = os.environ.get('HIVEMIND_PORT', '50052')
        if server_address is None:
            server_address = '127.0.0.1'
        target = f"{server_address}:{port}"
        
        options = [
            ('grpc.max_send_message_length', 100 * 1024 * 1024),
            ('grpc.max_receive_message_length', 100 * 1024 * 1024),
        ]
        self.channel = grpc.insecure_channel(target, options=options)
        self.stub = hivemind_pb2_grpc.DesktopCoordinatorStub(self.channel)
        
        self.is_real_time = isRealTime
        self._last_frame = None
        self._last_result = None
        self._running = True
        self._lock = threading.Lock()
        
        self.active_model_meta = self._sync_with_backend_ui()
        self.current_model_id = self.active_model_meta.get('name', 'default')
        
        if self.is_real_time:
            self._inference_thread = threading.Thread(target=self._bg_inference_loop, daemon=True)
            self._inference_thread.start()

        print(f"[HiveMind] 🟢 SDK Conectado. Motor: {self.current_model_id}")

    # --- 🧠 SECCIÓN GEN AI (TEXTO / LLMs) ---

    def chat(self, prompt, model_id=None):
        """
        Summary:
            Envía texto plano al enjambre. Ideal para modelos de lenguaje (Llama/Gemma).
            
            Uso: 
                respuesta = sdk.chat("¿Cuál es el clima en Marte?")
                print(respuesta['data']) # Imprime el string generado
        """
        return self.run_inference(prompt, model_id=model_id if model_id else self.current_model_id)

    # --- 🔊 SECCIÓN AUDIO (STT / TTS) ---

    def process_audio(self, audio_buffer):
        """
        Summary:
            Envía buffers de audio (PCM, WAV) para transcripción distribuida.
            
            Uso:
                texto = sdk.process_audio(my_audio_np_array)
        """
        return self.run_inference(audio_buffer, compress=False)

    # --- 👁️ SECCIÓN VISIÓN (REAL-TIME / YOLO) ---

    def update_frame(self, frame):
        """
        Summary:
            [SOLO REAL-TIME] Alimenta el buffer de video. El hilo de fondo tomará
            este frame para procesarlo mientras tu código sigue capturando.
        """
        if not self.is_real_time: return
        with self._lock:
            self._last_frame = frame

    def get_latest_result(self):
        """
        Summary:
            [SOLO REAL-TIME] Recupera el último análisis completado por los Androids.
            
            Uso (en bucle de video):
                frame = cam.read()
                sdk.update_frame(frame)
                res = sdk.get_latest_result() # No bloquea el video
        """
        with self._lock:
            return self._last_result

    # --- 🚀 MÉTODOS DE EJECUCIÓN MAESTROS ---

    def run_inference(self, input_data, model_id="default", compress=None):
        """
        Summary:
            Ejecución SÍNCRONA. Bloquea el código hasta recibir respuesta.
            Ideal para scripts simples o procesamiento de archivos uno por uno.
            
            Retorno: {data: np.array|str, success: bool, latency_ms: float}
        """
        start_t = time.perf_counter()
        try:
            req = self._prepare_request(input_data, model_id, compress=compress)
            res = self.stub.SubmitJob(req)
            latency = (time.perf_counter() - start_t) * 1000
            return self._process_response(res, latency)
        except Exception as e:
            return {"data": None, "success": False, "error": str(e), "latency_ms": 0}

    def run_async(self, input_data, model_id="default", compress=None):
        """
        Summary:
            Ejecución ASÍNCRONA (Paralelismo). Envía la tarea y sigue adelante.
            Devuelve un objeto 'Future'. Úsalo para repartir 100 tareas a 10 celulares.
            
            Uso:
                f = sdk.run_async(imagen)
                # ... hacer otras cosas ...
                res = sdk.resolve_future(f)
        """
        try:
            req = self._prepare_request(input_data, model_id, compress=compress)
            if req is None: return None
            f = self.stub.SubmitJob.future(req)
            f._start_time = time.perf_counter()
            return f
        except Exception as e:
            return None

    def resolve_future(self, future):
        """
        Summary:
            Espera y resuelve un 'Future' creado con run_async.
        """
        try:
            res = future.result() 
            start_t = getattr(future, '_start_time', time.perf_counter())
            latency = (time.perf_counter() - start_t) * 1000
            return self._process_response(res, latency)
        except Exception as e:
            return {"data": None, "success": False, "error": str(e), "latency_ms": 0}

    # --- ⚙️ MOTOR INTERNO (PREPARACIÓN Y PROCESAMIENTO) ---

    def _prepare_request(self, input_data, model_id, compress=None):
        """Prepara el paquete gRPC detectando el tipo de IA automáticamente."""
        data_bytes = b''
        shape = []
        dtype = "bytes"

        if isinstance(input_data, np.ndarray):
            shape = list(input_data.shape)
            dtype = str(input_data.dtype)
            data_bytes = input_data.tobytes()
        elif isinstance(input_data, str):
            data_bytes = input_data.encode('utf-8')
            shape = [len(data_bytes)]
            dtype = "string"
        elif isinstance(input_data, bytes):
            data_bytes = input_data
            shape = [len(input_data)]
            dtype = "bytes"
        else:
            arr = np.array(input_data)
            data_bytes = arr.tobytes()
            shape = list(arr.shape)
            dtype = str(arr.dtype)

        # Compresión: Nivel 5 para video, Nivel 0 para Texto corto
        if compress is None:
            comp_level = 5 if len(data_bytes) > 2048 else 0
        else:
            comp_level = 5 if compress else 0

        final_bytes = zlib.compress(data_bytes, level=comp_level) if comp_level > 0 else data_bytes

        return hivemind_pb2.ClientInferenceRequest(
            model_id=model_id, 
            input_bytes=final_bytes,
            input_shape=shape, 
            input_type=dtype,
            compression=1 if comp_level > 0 else 0
        )

    def _process_response(self, response, latency_ms):
        """
        ARQUITECTURA UNIVERSAL: 
        Prioriza la integridad del buffer sobre los metadatos de forma.
        """
        result = {
            "data": None,
            "success": not response.is_error,
            "latency_ms": round(latency_ms, 2),
            "error": response.error_message if response.is_error else None
        }
        
        if response.is_error or not response.output_bytes: 
            return result

        try:
            # 1. Tratamiento de Texto (Agnóstico a Shape)
            if response.output_type == "string":
                result["data"] = response.output_bytes.decode('utf-8')
                return result

            # 2. Reconstrucción Numérica Dinámica
            dtype_map = {
                "float32": np.float32, "float16": np.float16, 
                "uint8": np.uint8, "int32": np.int32
            }
            target_dtype = dtype_map.get(response.output_type.lower(), np.float32)
            
            # Cargamos la realidad física de los bytes
            data_array = np.frombuffer(response.output_bytes, dtype=target_dtype).copy()

            # 3. Lógica de Reshape Resiliente
            # Solo aplicamos reshape si el volumen de datos coincide EXACTAMENTE.
            # para que la aplicación superior decida cómo interpretarlo sin morir.
            if response.output_shape:
                target_shape = list(response.output_shape)
                try:
                    expected_elements = np.prod(target_shape)
                    if data_array.size == expected_elements:
                        data_array = data_array.reshape(target_shape)
                    else:
                        # 📢 SOLUCIÓN UNIVERSAL: Informar la discrepancia pero salvar el dato
                        print(f"[HiveMind Warning] ⚠️ Discrepancia de Contrato en '{self.current_model_id}':")
                        print(f"  -> El Android reportó forma {target_shape} ({expected_elements} elementos)")
                        print(f"  -> Pero envió físicamente {data_array.size} elementos.")
                        print(f"  -> Fallback: Devolviendo array plano para evitar colapso.")
                except Exception as shape_err:
                    print(f"[HiveMind Error] ❌ Error calculando forma: {shape_err}")
            
            result["data"] = data_array
            return result

        except Exception as e:
            result["success"] = False
            result["error"] = f"SDK Post-Process Error: {str(e)}"
            return result

    def _bg_inference_loop(self):
        """Motor de inferencia asíncrona para video en tiempo real."""
        while self._running:
            frame_to_process = None
            with self._lock: frame_to_process = self._last_frame
            if frame_to_process is not None:
                res = self.run_inference(frame_to_process, self.current_model_id)
                with self._lock: self._last_result = res
            else:
                time.sleep(0.01)

    def _sync_with_backend_ui(self):
        """Handshake mDNS con el Back para auto-configuración de modelos."""
        try:
            response = self.stub.GetActiveModelInfo(hivemind_pb2.Empty())
            return {"name": response.name, "input_shape": response.input_shape, "input_type": response.input_type}
        except: return {"name": "default"}

    def close(self):
        """Cierre seguro del canal gRPC."""
        self._running = False
        self.channel.close()