import os
import sys
import cv2
import numpy as np
import time

# ==========================================================
# 🔧 Asi se debería ver una importación limpia del SDK
# ==========================================================
# Agregamos dinámicamente las rutas para que como usuario no tenga
# que configurar variables de entorno manualmente.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SDK_DIR = os.path.join(BASE_DIR, "hivemind_sdk")
sys.path.append(SDK_DIR)

try:
    from hivemind_sdk.hivemind import HiveMind
    print("✅ [HiveMind] SDK inicializado con éxito.")
except ImportError:
    print("❌ [Error] No se encontró la carpeta 'hivemind_sdk' junto al script.")
    sys.exit(1)

# ==========================================================
# 🏷️ DICCIONARIO DE CLASES (COCO DATASET) esto es de YOLO
# ==========================================================
CLASSES = [
    'persona', 'bicicleta', 'carro', 'moto', 'avion', 'bus', 'tren', 'camion', 'bote', 'semaforo',
    'hidrante', 'stop', 'parquimetro', 'banca', 'pajaro', 'gato', 'perro', 'caballo', 'oveja', 'vaca',
    'elefante', 'oso', 'cebra', 'jirafa', 'mochila', 'paraguas', 'bolso', 'corbata', 'maleta', 'frisbee',
    'esquis', 'snowboard', 'balon', 'cometa', 'bate', 'guante', 'skateboard', 'tabla_surf', 'raqueta', 'botella',
    'copa', 'tenedor', 'cuchillo', 'cuchara', 'tazon', 'banana', 'manzana', 'sandwich', 'naranja', 'brocoli',
    'zanahoria', 'hot_dog', 'pizza', 'dona', 'pastel', 'silla', 'sofa', 'planta', 'cama', 'mesa',
    'inodoro', 'tv', 'laptop', 'mouse', 'control_remoto', 'teclado', 'celular', 'microondas', 'horno', 'tostador',
    'fregadero', 'refrigerador', 'libro', 'reloj', 'florero', 'tijeras', 'oso_peluche', 'secador', 'cepillo'
]

def main():
    # 1. Conexión al Enjambre (Auto-Sincronización con UI)
    # Al usar isRealTime=True, la IA no detiene la fluidez del video.
    # Si no necesitas video con real time colocalo en False (recomendado para deteeción en tiempo real de camaras e identificadores al vuelo)
    hm = HiveMind(server_address="127.0.0.1", port="50052", isRealTime=True)
    
    # 2. Acceso a Cámara
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("❌ Error: No se detectó ninguna cámara activa.")
        return

    print("🚀 Motor de Inferencia Distribuida en marcha...")
    print("💡 Tip: Presiona 'Q' para cerrar el programa de forma segura.")

    window_name = "HiveMind Swarm - Intelligent Vision"
    prev_time = time.time()

    while True:
        ret, frame = cap.read()
        if not ret: break

        # 3. PREPARACIÓN DE DATOS (Contrato Float32)
        # Redimensionamos a 640x640 y normalizamos a [0.0 - 1.0]
        # El SDK enviará estos datos de forma asíncrona al enjambre.
        input_ia = cv2.resize(frame, (640, 640)).astype(np.float32) / 255.0
        hm.update_frame(input_ia)
        
        # 4. RECUPERACIÓN DE RESULTADOS Y TELEMETRÍA
        # El SDK devuelve un objeto enriquecido con latencia y estado.
        response = hm.get_latest_result()

        if isinstance(response, dict) and response.get("success"):
            try:
                data = response.get("data")
                if data is not None:
                    # Formateo de salida YOLOv8 [84, 8400]
                    preds = data.reshape(84, 8400).T 
                    
                    h_img, w_img = frame.shape[:2]
                    scores = np.max(preds[:, 4:], axis=1)
                    
                    # Filtro de confianza estricto para evitar falsos positivos
                    mask = scores > 0.50 
                    valid_preds = preds[mask]
                    valid_scores = scores[mask]

                    for i in range(len(valid_preds)):
                        box = valid_preds[i]
                        conf = valid_scores[i]
                        class_id = np.argmax(box[4:])
                        
                        # Cálculo de Bounding Box (Centro a Esquinas)
                        cx, cy, w, h = box[:4]
                        x1 = int((cx - w/2) * w_img / 640)
                        y1 = int((cy - h/2) * h_img / 640)
                        x2 = int((cx + w/2) * w_img / 640)
                        y2 = int((cy + h/2) * h_img / 640)

                        # Dibujo profesional
                        label = f"{CLASSES[class_id].upper()} {int(conf*100)}%"
                        color = (0, 255, 0) # Verde Neón
                        
                        cv2.rectangle(frame, (max(0,x1), max(0,y1)), (min(w_img,x2), min(h_img,y2)), color, 2)
                        cv2.rectangle(frame, (max(0,x1), max(0,y1)-25), (max(0,x1)+200, max(0,y1)), color, -1)
                        cv2.putText(frame, label, (x1+5, y1-7), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,0), 2)

                    # --- TELEMETRÍA EN PANTALLA ---
                    latency = int(response.get("latency_ms", 0))
                    status_txt = f"SWARM LATENCY: {latency}ms"
                    cv2.putText(frame, status_txt, (w_img - 320, 35), 0, 0.8, (0, 255, 255), 2)
            
            except Exception as e:
                # El script ignora errores de renderizado para no detener el video
                pass

        # 5. MÉTRICAS DE VIDEO LOCAL
        curr_time = time.time()
        fps = 1 / (curr_time - prev_time + 1e-6)
        prev_time = curr_time
        cv2.putText(frame, f"LOCAL FPS: {int(fps)}", (20, 35), 0, 0.7, (255, 255, 255), 2)
        
        # Renderizado final
        cv2.imshow(window_name, frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Cierre limpio de recursos
    cap.release()
    cv2.destroyAllWindows()
    hm.close()
    print("👋 Gracias por usar HiveMind.")

if __name__ == "__main__":
    main()