Debes crear tu carpeta venv e instala aqui las librerias que el ejemplo detector_hivemind.py necesita.
